import { useState, useEffect } from 'react';

function Cadastro() {
    const [input, setInput] = useState('');
    const [tarefas, setTarefas] = useState([
        "Pagar a conta de luz",
        "Estudar Programação",
        "Enviar Tarefa"
    ]);
    const [nome, setNome] = useState('');
    const [cor, setCor] = useState('');

    useEffect(() => {
        const tarefasStorage = localStorage.getItem('@tarefa');
        if (tarefasStorage) {
            setTarefas(JSON.parse(tarefasStorage));
        }
    }, []);
    
    useEffect(() => {
        localStorage.setItem('@tarefa', JSON.stringify(tarefas));
    }, [tarefas]);

    useEffect(() => {
        const nomeSalvo = localStorage.getItem('@nomeUsuario');
        if (!nomeSalvo) {
            const nomeUsuario = prompt("Qual é o seu nome?");
            if (nomeUsuario) {
                setNome(nomeUsuario);
                localStorage.setItem('@nomeUsuario', nomeUsuario);
            }
        } else {
            setNome(nomeSalvo);
        }
    }, []);

    useEffect(() => {
        document.body.style.backgroundColor = cor;
    }, [cor]);

    function handleRegistro(e) {
        e.preventDefault();
        setTarefas([...tarefas, input]);
        setInput('');
    }

    return (
        <div>
            <h1>Bem-vindo, {nome}, sua lista de tarefas</h1>
            <h2>Cadastro de Tarefas</h2>
            
            <form onSubmit={handleRegistro}>
                <label>Nome da Tarefa: </label><br />
                <input 
                    placeholder='Digite uma Tarefa'
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                /><br />
                <button type='submit'>Registro</button>
            </form>
            <br />
            
            <h3>Escolha uma cor:</h3>
            <label>
                <input type="radio" value="red" checked={cor === "red"} onChange={(e) => setCor(e.target.value)} /> Vermelho
            </label>
            <label>
                <input type="radio" value="blue" checked={cor === "blue"} onChange={(e) => setCor(e.target.value)} /> Azul
            </label>
            <label>
                <input type="radio" value="green" checked={cor === "green"} onChange={(e) => setCor(e.target.value)} /> Verde
            </label>
            <label>
                <input type="radio" value="yellow" checked={cor === "yellow"} onChange={(e) => setCor(e.target.value)} /> Amarelo
            </label>
            
            <br />
            <ul>
                {tarefas.map((tarefa, index) => (
                    <li key={index}>{tarefa}</li>
                ))}
            </ul>
        </div>
    );
}

export default Cadastro;

