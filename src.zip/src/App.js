import Nome from './Components/Nome';
import { useState } from 'react';

function App() {
  const [aluno, setAluno]= useState('Aluno')

  function handleChangeName(){
    setAluno('Marcio')
  }

  return (
    <div>
      <h1>Minha Pagina Web!</h1>
      <h2>Olá {aluno}</h2>
      <button onClick={() => handleChangeName('Marcio Funes')}>
        Mudar nome
      </button>
    </div>
  );
}

export default App;
